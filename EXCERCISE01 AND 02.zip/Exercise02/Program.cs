﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Exercise02
{
    class Program
    {
        static void Main(string[] args)
        {
            var positiveString = "18456002032011000007";
            var number = BigInteger.Parse(positiveString);
            var word = Exercise01.Exercise01.NumberToWords(number);
            Console.WriteLine(word);
            Console.ReadKey();
        }

    }
}
