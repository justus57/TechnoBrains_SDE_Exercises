﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using EmployeesCSV;
using System.Numerics;


namespace UnitTestProject
{
    using Exercise01;
    [TestClass]
    public class UnitTest1
    {      
        [TestMethod]
        public void Employeetest()
        {
            string path = AppDomain.CurrentDomain.BaseDirectory + @"\DATA.CSV";
            Employee.Readcsvfile(path);
            long amount = Employee.Bubget(path, "Employee2");
            Assert.IsNotNull(amount);
        }

        [TestMethod]
        public void Exercise2()
        {
            var positiveString = "18456002032011000007";
            var number = BigInteger.Parse(positiveString);
            var word = Exercise01.NumberToWords(number);
            Assert.IsNotNull(word);
        }
    }
}
