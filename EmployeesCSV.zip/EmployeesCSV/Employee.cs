﻿using LINQtoCSV;
using System;
using System.Collections.Generic;
using System.Linq;

namespace EmployeesCSV
{
    public class Employee
    {
        private static long amount;
        public static IEnumerable<Employees> employees { get; private set; }
        public static void Readcsvfile(string file)
        {
            IEnumerable<Employees> employees = Read(file);

            foreach (var employee in employees)
            {
                Console.WriteLine($"{employee.EmployeeID}|{employee.ManagerID}|{employee.Salary}");
            }
        }
        /// <summary>
        /// private function for reading the csv file in string format
        /// </summary>
        /// <param name="file"></param>
        /// <returns></returns>
        private static IEnumerable<Employees> Read(string file)
        {
            try
            {
                var csvFileDescription = new CsvFileDescription
                {
                    FirstLineHasColumnNames = true,
                    IgnoreUnknownColumns = true,
                    SeparatorChar = ',',
                };

                var csvContext = new CsvContext();
                employees = csvContext.Read<Employees>(file, csvFileDescription);
            }
            catch (Exception es)
            {
                Console.WriteLine(es.Message);
            }
            return employees;
        }
        /// <summary>
        /// function for the total budget 
        /// </summary>
        /// <param name="value"></param>
        /// <param name="employeeid"></param>
        /// <returns></returns>
        public static long Bubget(string value, string employeeid)
        {
            string salary = string.Empty;

            List<Managed> amounts = new List<Managed>();
            try
            {
                //call the read function 
                IEnumerable<Employees> employees = Read(value);

                foreach (var employee in employees)
                {
                    if (employee.ManagerID == employeeid)
                    {
                        salary = employee.Salary;
                        amounts.Add(new Managed() { EmpolyeeID = employee.EmployeeID, salary = salary });
                    }
                }
                //get the total salary for employee
                amount = (long)amounts.Sum(x => Convert.ToDouble(x.salary));
            }
            catch (Exception es)
            {
                Console.WriteLine(es.Message);
            }
            return amount;
        }
    }
    public class Employees
    {
        public string EmployeeID { get; set; }
        public string ManagerID { get; set; }
        public string Salary { get; set; }
    }
}
