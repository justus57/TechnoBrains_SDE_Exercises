﻿namespace EmployeesCSV
{
    public class Managed
    {
        public string EmpolyeeID;
        public string salary;
    }
}
